import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFF6366F1);
  static const Color backgroundColor = Color(0xFFF5F5F5);
  static const Color success = Color(0xFF10B981);
  static const Color error = Color(0xFFEF4444);
}