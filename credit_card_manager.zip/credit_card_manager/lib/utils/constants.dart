class AppConstants {
  static const String appName = 'Credit Card Manager';
  static const String currency = '₹';
}