package com.example.credit_card_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
